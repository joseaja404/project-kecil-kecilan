<?php
require 'config.php';

// Ambil peringkat hacker berdasarkan jumlah reward Resolved dan total poin/bounty
$leaderboard_query = @$conn->query("SELECT users.id, users.username, users.profile_pic, 
                                    COUNT(reports.id) AS total_resolved, 
                                    SUM(reports.reward) AS total_bounty 
                                    FROM users 
                                    JOIN reports ON users.id = reports.hacker_id 
                                    WHERE users.role = 'hacker' AND reports.status = 'Resolved' 
                                    GROUP BY users.id 
                                    ORDER BY total_bounty DESC, total_resolved DESC 
                                    LIMIT 20");

// Pengaman: jika query gagal (mis. tabel/kolom belum siap), jangan fatal error —
// tampilkan saja leaderboard kosong.
if ($leaderboard_query === false) {
    $leaderboard_query = null;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard & Hall of Fame - HackerCrowd Project</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="assets/img/logo.svg">
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-slate-900 px-4 py-3 border-bottom border-secondary">
    <a class="navbar-brand fw-bold d-flex align-items-center" href="index.php">
        <i class="bi bi-shield-lock-fill text-success fs-3 me-2"></i> Hacker<span class="text-success">Crowd</span> Project
    </a>
    <div class="ms-auto d-flex align-items-center">
        <a href="index.php" class="btn btn-outline-light btn-sm me-2 rounded-pill px-3"><i class="bi bi-house me-1"></i> Home</a>
        <?php if(isset($_SESSION['user_id'])): ?>
            <a href="dashboard.php" class="btn btn-outline-success btn-sm rounded-pill px-3"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a>
        <?php else: ?>
            <a href="login.php" class="btn btn-success btn-sm rounded-pill px-3">Login</a>
        <?php endif; ?>
    </div>
</nav>

<div class="container my-5" style="max-width: 850px;">
    
    <div class="text-center mb-5">
        <div class="bg-warning bg-opacity-10 text-warning rounded-circle d-inline-flex p-3 mb-3 border border-warning border-opacity-25 shadow">
            <i class="bi bi-trophy-fill display-5"></i>
        </div>
        <h2 class="fw-bold text-white">Hacker Hall of Fame & Leaderboard 🏆</h2>
        <p class="text-secondary opacity-75">Daftar peneliti keamanan teratas yang paling aktif dan berkontribusi mengamankan ekosistem platform.</p>
    </div>

    <div class="leaderboard-card p-4 shadow-lg">
        <div class="table-responsive">
            <table class="table table-dark table-dark-custom align-middle mb-0">
                <thead>
                    <tr>
                        <th class="ps-3" style="width: 80px;">Peringkat</th>
                        <th>Peneliti Keamanan (Hacker)</th>
                        <th class="text-center">Temuan Resolved</th>
                        <th class="text-end pe-3">Total Bounty Earned</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $rank = 1;
                    if ($leaderboard_query && $leaderboard_query->num_rows > 0):
                        while($row = $leaderboard_query->fetch_assoc()): 
                            $rank_class = '';
                            if ($rank == 1) $rank_class = 'podium-1 fs-5';
                            elseif ($rank == 2) $rank_class = 'podium-2 fs-6';
                            elseif ($rank == 3) $rank_class = 'podium-3 fs-6';
                    ?>
                    <tr>
                        <td class="ps-3 text-center">
                            <span class="<?= $rank_class ?>">
                                <?php if($rank == 1): ?>🥇 <?= $rank ?>
                                <?php elseif($rank == 2): ?>🥈 <?= $rank ?>
                                <?php elseif($rank == 3): ?>🥉 <?= $rank ?>
                                <?php else: ?>#<?= $rank ?>
                                <?php endif; ?>
                            </span>
                        </td>
                        <td>
                            <div class="d-flex align-items-center">
                                <?php if (!empty($row['profile_pic']) && file_exists('uploads/' . $row['profile_pic'])): ?>
                                    <img src="uploads/<?= htmlspecialchars($row['profile_pic']) ?>" class="rank-avatar me-3" alt="Avatar">
                                <?php else: ?>
                                    <img src="https://api.dicebear.com/7.x/identicon/svg?seed=<?= urlencode($row['username']) ?>" class="rank-avatar me-3 bg-secondary" alt="Avatar">
                                <?php endif; ?>
                                <div>
                                    <span class="fw-bold text-white fs-6"><?= htmlspecialchars($row['username']) ?></span>
                                    <small class="text-muted d-block font-monospace">ID: #<?= $row['id'] ?></small>
                                </div>
                            </div>
                        </td>
                        <td class="text-center">
                            <span class="badge bg-success bg-opacity-75 px-3 py-1"><?= $row['total_resolved'] ?> Laporan</span>
                        </td>
                        <td class="text-end pe-3 text-success fw-bold fs-5">
                            $<?= number_format($row['total_bounty']) ?>
                        </td>
                    </tr>
                    <?php 
                        $rank++;
                        endwhile; 
                    else:
                    ?>
                        <tr>
                            <td colspan="4" class="text-center text-secondary py-5">
                                <i class="bi bi-shield-slash display-4 d-block mb-2 text-muted"></i>
                                Belum ada data peringkat atau laporan yang berstatus Resolved.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/lenis@1.1.18/dist/lenis.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>