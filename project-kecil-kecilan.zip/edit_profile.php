<?php
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$success = '';
$error   = '';

// Ambil data user saat ini
$stmt = $conn->prepare("SELECT username, email, role, profile_pic FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username     = trim($_POST['username']);
    $email        = trim($_POST['email']);
    $new_password = $_POST['new_password'];
    $profile_pic  = $user['profile_pic'];

    // Handle Upload Foto Profil
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0) {
        $allowed_ext = ['jpg', 'jpeg', 'png', 'webp'];
        $file_name   = $_FILES['profile_pic']['name'];
        $file_tmp    = $_FILES['profile_pic']['tmp_name'];
        $file_ext    = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (in_array($file_ext, $allowed_ext)) {
            // Buat folder uploads jika belum ada
            if (!is_dir('uploads')) {
                mkdir('uploads', 0777, true);
            }

            $new_file_name = 'avatar_' . $user_id . '_' . time() . '.' . $file_ext;
            $upload_path   = 'uploads/' . $new_file_name;

            if (move_uploaded_file($file_tmp, $upload_path)) {
                // Hapus foto lama jika ada
                if (!empty($user['profile_pic']) && file_exists('uploads/' . $user['profile_pic'])) {
                    unlink('uploads/' . $user['profile_pic']);
                }
                $profile_pic = $new_file_name;
            } else {
                $error = "Gagal mengunggah file foto.";
            }
        } else {
            $error = "Format foto tidak valid! Gunakan JPG, JPEG, PNG, atau WEBP.";
        }
    }

    if (empty($error)) {
        // Catatan: mysqli di proyek ini tidak diaktifkan dalam mode exception
        // (MYSQLI_REPORT_STRICT), sehingga try/catch(mysqli_sql_exception) tidak
        // pernah tertangkap — execute() yang gagal hanya mengembalikan false.
        // Deteksi kegagalan lewat nilai balik & kode error di bawah ini.
        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt_update = $conn->prepare("UPDATE users SET username = ?, email = ?, password = ?, profile_pic = ? WHERE id = ?");
            $stmt_update->bind_param("ssssi", $username, $email, $hashed_password, $profile_pic, $user_id);
        } else {
            $stmt_update = $conn->prepare("UPDATE users SET username = ?, email = ?, profile_pic = ? WHERE id = ?");
            $stmt_update->bind_param("sssi", $username, $email, $profile_pic, $user_id);
        }

        if ($stmt_update->execute()) {
            $_SESSION['username']  = $username;
            $user['username']      = $username;
            $user['email']         = $email;
            $user['profile_pic']   = $profile_pic;
            $success = "Profil dan foto berhasil diperbarui!";
        } else if ($conn->errno == 1062) {
            $error = "Email sudah digunakan oleh akun lain!";
        } else {
            $error = "Gagal memperbarui profil di database.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - HackerCrowd Project</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="assets/img/logo.svg">
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-slate-900 px-4 py-3 border-bottom border-secondary">
    <a class="navbar-brand fw-bold" href="index.php">
        <i class="bi bi-shield-lock-fill text-success fs-3 me-2"></i> Hacker<span class="text-success">Crowd</span> Project
    </a>
    <div class="ms-auto">
        <a href="dashboard.php" class="btn btn-outline-light btn-sm me-2 rounded-pill px-3"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <a href="logout.php" class="btn btn-danger btn-sm rounded-pill px-3"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
</nav>

<div class="container my-5" style="max-width: 540px;">
    <div class="text-center mb-4">
        <?php if (!empty($user['profile_pic']) && file_exists('uploads/' . $user['profile_pic'])): ?>
            <img src="uploads/<?= htmlspecialchars($user['profile_pic']) ?>" class="rounded-circle avatar-preview shadow mb-2" alt="Avatar">
        <?php else: ?>
            <img src="https://api.dicebear.com/7.x/bottts/svg?seed=<?= urlencode($user['username']) ?>" class="rounded-circle avatar-preview shadow mb-2 bg-dark" alt="Avatar">
        <?php endif; ?>
        <h3 class="fw-bold">Pengaturan Profil</h3>
        <p class="text-secondary small">Perbarui foto, informasi akun, dan keamanan kata sandi Anda</p>
    </div>

    <?php if(!empty($success)): ?>
        <div class="alert alert-success d-flex align-items-center py-2" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <?php if(!empty($error)): ?>
        <div class="alert alert-danger d-flex align-items-center py-2" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <div class="profile-card p-4 shadow-lg">
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label small fw-bold text-light">Unggah Foto Profil Baru</label>
                <input type="file" name="profile_pic" class="form-control bg-dark text-white border-secondary">
                <div class="form-text text-muted small">Format yang didukung: JPG, JPEG, PNG, WEBP.</div>
            </div>

            <div class="mb-3">
                <label class="form-label small fw-bold text-light">Username</label>
                <div class="input-group">
                    <span class="input-group-text bg-dark border-secondary text-secondary"><i class="bi bi-person"></i></span>
                    <input type="text" name="username" class="form-control bg-dark text-white border-secondary" value="<?= htmlspecialchars($user['username']) ?>" required>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label small fw-bold text-light">Alamat Email</label>
                <div class="input-group">
                    <span class="input-group-text bg-dark border-secondary text-secondary"><i class="bi bi-envelope"></i></span>
                    <input type="email" name="email" class="form-control bg-dark text-white border-secondary" value="<?= htmlspecialchars($user['email']) ?>" required>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label small fw-bold text-light">Peran Akun (Role)</label>
                <input type="text" class="form-control bg-dark text-secondary border-secondary" value="<?= ucfirst($user['role']) ?>" disabled>
            </div>

            <hr class="border-secondary my-4">

            <div class="mb-4">
                <label class="form-label small fw-bold text-light">Password Baru <span class="text-muted fw-normal">(Kosongkan jika tidak ingin diubah)</span></label>
                <div class="input-group">
                    <span class="input-group-text bg-dark border-secondary text-secondary"><i class="bi bi-key"></i></span>
                    <input type="password" name="new_password" class="form-control bg-dark text-white border-secondary" placeholder="••••••••">
                </div>
            </div>

            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-success py-2 fw-bold">
                    <i class="bi bi-save me-1"></i> Simpan Perubahan
                </button>
                <a href="dashboard.php" class="btn btn-outline-secondary py-2">Kembali ke Dashboard</a>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/lenis@1.1.18/dist/lenis.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>