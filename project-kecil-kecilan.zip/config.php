<?php
// Mulai session di setiap halaman yang memuat config.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Konfigurasi Database (env override untuk preview lokal; default = kredensial InfinityFree)
$host     = getenv('DB_HOST') ?: "sql105.infinityfree.com";
$user     = getenv('DB_USER') ?: "if0_43145767";
$password = (getenv('DB_PASS') !== false) ? getenv('DB_PASS') : "Garuda195";
$dbname   = getenv('DB_NAME') ?: "if0_43145767_hackercrowd";

// Membuat koneksi MySQLi
$conn = new mysqli($host, $user, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

// Set charset ke utf8mb4 untuk mendukung karakter khusus dan emoji
$conn->set_charset("utf8mb4");

/**
 * Bootstrap Skema Database (Single Source of Truth)
 *
 * Sebelumnya setiap halaman membuat/mengubah tabelnya sendiri secara
 * terpisah (mis. company_dashboard.php membuat tabel "vdp_programs"
 * sementara dashboard.php & submit_report.php membaca dari tabel
 * "programs"). Akibatnya program yang dipublikasikan company tidak
 * pernah muncul di sisi hacker, dan laporan yang dikirim hacker tidak
 * bisa dibuka kembali karena kolom yang dibutuhkan belum ada.
 *
 * Fungsi ini memastikan semua tabel inti dibuat sekali, dengan nama
 * tabel & kolom yang SAMA di semua halaman. Aman dipanggil berkali-kali
 * (CREATE TABLE IF NOT EXISTS / ADD COLUMN IF NOT EXISTS).
 */
function ensure_schema($conn) {
    // Tabel Program VDP / Bug Bounty (dipublikasikan oleh Company)
    $conn->query("CREATE TABLE IF NOT EXISTS programs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        scope TEXT,
        reward VARCHAR(100) DEFAULT '',
        status VARCHAR(50) DEFAULT 'Live',
        verification_status VARCHAR(50) DEFAULT 'Active/Pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Tabel Laporan Kerentanan (dikirim oleh Hacker)
    $conn->query("CREATE TABLE IF NOT EXISTS reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        hacker_id INT NOT NULL,
        program_id INT DEFAULT NULL,
        title VARCHAR(255) NOT NULL,
        vulnerability_type VARCHAR(100) DEFAULT 'Lainnya / Umum',
        severity VARCHAR(20) DEFAULT 'Medium',
        vulnerability_details TEXT,
        attachment VARCHAR(255) DEFAULT NULL,
        status VARCHAR(50) DEFAULT 'New',
        payment_status VARCHAR(20) DEFAULT 'Unpaid',
        reward DECIMAL(10,2) DEFAULT 0.00,
        verification_status VARCHAR(50) DEFAULT 'Active/Pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Komentar/diskusi pada laporan
    $conn->query("CREATE TABLE IF NOT EXISTS report_comments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        report_id INT NOT NULL,
        user_id INT NOT NULL,
        comment TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Pesan langsung antar pengguna
    $conn->query("CREATE TABLE IF NOT EXISTS messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sender_id INT NOT NULL,
        receiver_id INT NOT NULL,
        message TEXT NOT NULL,
        is_read TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Log aktivitas (audit trail)
    $conn->query("CREATE TABLE IF NOT EXISTS activity_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT DEFAULT NULL,
        action VARCHAR(100) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Kolom tambahan pada users untuk profil & slip pajak (defensif,
    // untuk database lama yang sudah ada sebelum kolom ini ditambahkan)
    @$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS profile_pic VARCHAR(255) DEFAULT NULL");
    @$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS fullname VARCHAR(255) DEFAULT ''");
    @$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS ptkp_status VARCHAR(20) DEFAULT 'TK/0'");
}
ensure_schema($conn);

/**
 * Fungsi Global untuk Mencatat Log Aktivitas (Audit Trail)
 * 
 * @instance mysqli $conn Koneksi database
 * @param int|null $user_id ID pengguna yang melakukan aksi (null jika guest)
 * @param string $action Nama aksi (Contoh: "DELETE_USER", "LOGIN", "CREATE_PROGRAM")
 * @param string $description Deskripsi detail kejadian
 */
function log_activity($conn, $user_id, $action, $description) {
    // Pastikan tabel activity_logs sudah dibuat di database
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, action, description) VALUES (?, ?, ?)");
    if ($stmt) {
        // Jika user_id bernilai null/kosong, set sebagai NULL di database
        $uid = ($user_id !== null && is_numeric($user_id)) ? intval($user_id) : NULL;
        $stmt->bind_param("iss", $uid, $action, $description);
        $stmt->execute();
        $stmt->close();
    }
}
?>