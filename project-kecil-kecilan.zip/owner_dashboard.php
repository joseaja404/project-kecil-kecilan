<?php
// Aktifkan pelaporan error untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Panggil konfigurasi atau mulai session
if (file_exists('config.php')) {
    require_once 'config.php';
} else {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

// Proteksi: Hanya role 'owner' yang boleh mengakses
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'owner') {
    header("Location: login.php");
    exit;
}

$success_msg = "";
$error_msg = "";

// ---------------------------------------------------------------------
// 1. Handle Aksi Update Status Verifikasi VDP / Laporan
// ---------------------------------------------------------------------
if (isset($_GET['action']) && $_GET['action'] === 'update_verification' && isset($_GET['id']) && isset($_GET['status']) && isset($_GET['type']) && isset($conn)) {
    $item_id = intval($_GET['id']);
    $item_type = trim($_GET['type']); // 'report' atau 'vdp'
    $new_ver_status = trim($_GET['status']);
    $allowed_ver_statuses = ['Verified', 'Pending', 'Rejected', 'Active/Pending'];

    if (in_array($new_ver_status, $allowed_ver_statuses)) {
        if ($item_type === 'report') {
            $stmt_up = $conn->prepare("UPDATE reports SET verification_status = ? WHERE id = ?");
        } else {
            $stmt_up = $conn->prepare("UPDATE programs SET verification_status = ? WHERE id = ?");
        }

        if ($stmt_up) {
            $stmt_up->bind_param("si", $new_ver_status, $item_id);
            if ($stmt_up->execute()) {
                $success_msg = "Status verifikasi untuk {$item_type} #{$item_id} berhasil diperbarui menjadi [{$new_ver_status}]!";
            } else {
                $error_msg = "Gagal memperbarui status verifikasi di database.";
            }
        }
    } else {
        $error_msg = "Status verifikasi tidak valid.";
    }
}

// ---------------------------------------------------------------------
// 2. Handle Aksi Hapus Pengguna (User Moderation)
// ---------------------------------------------------------------------
if (isset($_GET['action']) && $_GET['action'] === 'delete_user' && isset($_GET['id']) && isset($conn)) {
    $target_id = intval($_GET['id']);
    if ($target_id !== intval($_SESSION['user_id'])) {
        $stmt_del = $conn->prepare("DELETE FROM users WHERE id = ?");
        if ($stmt_del) {
            $stmt_del->bind_param("i", $target_id);
            if ($stmt_del->execute()) {
                $success_msg = "Akun pengguna dengan ID #{$target_id} berhasil dihapus dari sistem.";
            } else {
                $error_msg = "Gagal menghapus pengguna dari database.";
            }
        }
    } else {
        $error_msg = "Anda tidak dapat menghapus akun owner yang sedang aktif!";
    }
}

// ---------------------------------------------------------------------
// 3. Handle Aksi Hapus VDP / Laporan
// ---------------------------------------------------------------------
if (isset($_GET['action']) && $_GET['action'] === 'delete_item' && isset($_GET['id']) && isset($_GET['type']) && isset($conn)) {
    $target_id = intval($_GET['id']);
    $item_type = trim($_GET['type']);

    if ($item_type === 'report') {
        @$conn->query("DELETE FROM reports WHERE id = $target_id");
    } else {
        @$conn->query("DELETE FROM programs WHERE id = $target_id");
    }
    $success_msg = "Item {$item_type} dengan ID #{$target_id} berhasil dihapus.";
}

// Statistik Owner
$total_users = 0;
$total_programs = 0;
$total_reports = 0;

if (isset($conn)) {
    $res_u = @$conn->query("SELECT COUNT(*) as cnt FROM users");
    if ($res_u) { $d = $res_u->fetch_assoc(); $total_users = $d['cnt'] ?? 0; }

    $res_p = @$conn->query("SELECT COUNT(*) as cnt FROM programs");
    if ($res_p) { $d = $res_p->fetch_assoc(); $total_programs = $d['cnt'] ?? 0; }

    $res_r = @$conn->query("SELECT COUNT(*) as cnt FROM reports");
    if ($res_r) { $d = $res_r->fetch_assoc(); $total_reports = $d['cnt'] ?? 0; }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Owner Command Center - HackerCrowd</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="assets/img/logo.svg">
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>

<div class="aurora-orb-dash orb-dash-1"></div>
<div class="aurora-orb-dash orb-dash-2"></div>

<!-- Top Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom px-4 py-3 sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold d-flex align-items-center" href="owner_dashboard.php">
            <i class="bi bi-shield-shaded text-danger fs-3 me-2"></i>
            <span class="fs-4">Hacker<span class="text-danger">Crowd</span></span>
            <span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25 ms-3 px-3 py-1 fs-6 rounded-pill fw-semibold"><i class="bi bi-shield-lock-fill me-1"></i> Owner Command Center</span>
        </a>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <a href="leaderboard.php" class="btn btn-sm btn-outline-danger fw-bold px-3 rounded-pill border-opacity-50 py-2"><i class="bi bi-trophy me-1"></i> Leaderboard</a>
            <a href="messages.php" class="btn btn-sm btn-outline-danger fw-bold px-3 rounded-pill border-opacity-50 py-2"><i class="bi bi-chat-dots me-1"></i> Live Chat</a>
            <a href="ai_assistant.php" class="btn btn-sm btn-outline-danger fw-bold d-flex align-items-center px-3 rounded-pill border-opacity-50 py-2">
                <i class="bi bi-cpu me-2"></i> AI Hacker Copilot
            </a>
            <a href="logout.php" class="btn btn-sm btn-outline-light fw-bold px-3 rounded-pill border-opacity-50 py-2"><i class="bi bi-box-arrow-right me-1"></i> Keluar</a>
        </div>
    </div>
</nav>

<!-- Main Container -->
<div class="container my-5" style="max-width: 1200px;">
    
    <?php if (!empty($success_msg)): ?>
        <div class="alert alert-success bg-success bg-opacity-15 border border-success text-success mb-4 rounded-3 py-3 px-4">
            <i class="bi bi-check-circle-fill me-2"></i> <?= htmlspecialchars($success_msg); ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($error_msg)): ?>
        <div class="alert alert-danger bg-danger bg-opacity-15 border border-danger text-danger mb-4 rounded-3 py-3 px-4">
            <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($error_msg); ?>
        </div>
    <?php endif; ?>

    <!-- Welcome Banner -->
    <div class="card-stat p-4 mb-4 border-danger border-opacity-25">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <div class="d-flex align-items-center gap-2 mb-2">
                    <span class="status-dot"></span>
                    <span class="text-danger small fw-semibold text-uppercase tracking-wider">Superadmin Command Protocol Active</span>
                </div>
                <h2 class="fw-bold text-white mb-2">Owner Command Center</h2>
                <p class="text-secondary small mb-0">Kelola seluruh pengguna sistem, moderasi akun, serta perbarui status verifikasi program VDP & laporan keamanan secara global.</p>
            </div>
            <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">
                <span class="badge bg-dark border border-secondary text-secondary px-3 py-2 rounded-pill font-monospace">Authorization: ROOT</span>
            </div>
        </div>
    </div>

    <!-- Analytics Cards -->
    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="card card-stat p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-secondary small text-uppercase fw-bold">Total Pengguna</span>
                    <div class="stat-icon-wrapper text-danger"><i class="bi bi-people-fill"></i></div>
                </div>
                <h1 class="fw-bold text-white display-5 mb-1"><?= $total_users ?></h1>
                <div class="text-danger small fw-semibold"><i class="bi bi-person-check me-1"></i> Terdaftar di database</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-stat p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-secondary small text-uppercase fw-bold">Program VDP Global</span>
                    <div class="stat-icon-wrapper text-success"><i class="bi bi-shield-check"></i></div>
                </div>
                <h1 class="fw-bold text-white display-5 mb-1"><?= $total_programs ?></h1>
                <div class="text-success small fw-semibold"><i class="bi bi-globe me-1"></i> Target perusahaan</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-stat p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-secondary small text-uppercase fw-bold">Total Laporan Bug</span>
                    <div class="stat-icon-wrapper text-info"><i class="bi bi-file-earmark-text-fill"></i></div>
                </div>
                <h1 class="fw-bold text-white display-5 mb-1"><?= $total_reports ?></h1>
                <div class="text-info small fw-semibold"><i class="bi bi-send-check me-1"></i> Submissions global</div>
            </div>
        </div>
    </div>

    <!-- Tabel 1: Manajemen & Moderasi Pengguna -->
    <div class="card card-stat p-4 mb-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h5 class="fw-bold text-white mb-1"><i class="bi bi-people-fill text-danger me-2"></i>Manajemen & Moderasi Pengguna</h5>
                <p class="text-secondary small mb-0">Daftar seluruh akun yang terdaftar di dalam database sistem.</p>
            </div>
            <span class="badge bg-dark border border-secondary text-secondary px-3 py-2 rounded-pill">User Control Center</span>
        </div>
        <div class="table-responsive">
            <table class="table table-dark-custom align-middle mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th class="text-end">Aksi Moderasi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (isset($conn)) {
                        $q_users = @$conn->query("SELECT * FROM users ORDER BY id DESC");
                        if ($q_users && $q_users->num_rows > 0) {
                            while ($u = $q_users->fetch_assoc()) {
                                $u_id = $u['id'];
                                $uname = $u['username'] ?? 'User #' . $u_id;
                                $email = $u['email'] ?? '-';
                                $role = strtoupper($u['role'] ?? 'HACKER');
                                
                                $role_badge = 'bg-success bg-opacity-10 text-success border border-success border-opacity-25';
                                if ($role === 'OWNER') $role_badge = 'bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25';
                                elseif ($role === 'COMPANY') $role_badge = 'bg-info bg-opacity-10 text-info border border-info border-opacity-25';

                                echo "<tr>";
                                echo "<td class='text-secondary font-monospace'>#{$u_id}</td>";
                                echo "<td class='fw-semibold text-white'>" . htmlspecialchars($uname) . "</td>";
                                echo "<td class='text-secondary'>" . htmlspecialchars($email) . "</td>";
                                echo "<td><span class='badge {$role_badge} px-2.5 py-1 rounded-pill'>" . htmlspecialchars($role) . "</span></td>";
                                echo "<td><span class='badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2.5 py-1'><i class='bi bi-dot'></i> Active</span></td>";
                                echo "<td class='text-end'>";
                                if (intval($_SESSION['user_id']) !== intval($u_id)) {
                                    echo "<a href='owner_dashboard.php?action=delete_user&id={$u_id}' class='btn btn-sm btn-outline-danger py-1 px-3' onclick=\"return confirm('Yakin ingin menghapus akun ini?');\"><i class='bi bi-trash-fill me-1'></i> Hapus</a>";
                                } else {
                                    echo "<span class='text-muted small'><i class='bi bi-shield-lock me-1'></i> Protected</span>";
                                }
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='6' class='text-center text-muted py-4'>Belum ada pengguna terdaftar.</td></tr>";
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Tabel 2: Manajemen VDP & Laporan (Dengan Interaktif Status Verifikasi) -->
    <div class="card card-stat p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h5 class="fw-bold text-white mb-1"><i class="bi bi-shield-exclamation text-warning me-2"></i>Manajemen VDP & Laporan Keamanan</h5>
                <p class="text-secondary small mb-0">Tinjau, ubah status verifikasi, atau hapus program VDP / laporan bug.</p>
            </div>
            <span class="badge bg-dark border border-secondary text-secondary px-3 py-2 rounded-pill">Reports & VDP Moderation</span>
        </div>
        <div class="table-responsive">
            <table class="table table-dark-custom align-middle mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Judul Laporan / VDP</th>
                        <th>Status Verifikasi</th>
                        <th class="text-end">Ubah Status & Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (isset($conn)) {
                        $has_data = false;

                        // 1. Tampilkan dari tabel reports
                        $chk_r = @$conn->query("SHOW TABLES LIKE 'reports'");
                        if ($chk_r && $chk_r->num_rows > 0) {
                            $r_cols = [];
                            $res_rc = @$conn->query("SHOW COLUMNS FROM reports");
                            if ($res_rc) { while ($rc = $res_rc->fetch_assoc()) { $r_cols[] = $rc['Field']; } }
                            $title_field_r = in_array('report_title', $r_cols) ? 'report_title' : (in_array('title', $r_cols) ? 'title' : 'id');

                            $q_r = @$conn->query("SELECT id, {$title_field_r} as title, 'report' as type, verification_status FROM reports ORDER BY id DESC LIMIT 15");
                            if ($q_r && $q_r->num_rows > 0) {
                                while ($row = $q_r->fetch_assoc()) {
                                    $has_data = true;
                                    renderRow($row);
                                }
                            }
                        }

                        // 2. Tampilkan dari tabel programs (VDP)
                        $q_v = @$conn->query("SELECT id, title, 'vdp' as type, verification_status FROM programs ORDER BY id DESC LIMIT 15");
                        if ($q_v && $q_v->num_rows > 0) {
                            while ($row = $q_v->fetch_assoc()) {
                                $has_data = true;
                                renderRow($row);
                            }
                        }

                        if (!$has_data) {
                            echo "<tr><td colspan='4' class='text-center text-muted py-5'>Belum ada program VDP atau laporan yang masuk.</td></tr>";
                        }
                    }

                    // Fungsi helper untuk merender baris tabel dengan badge tipe yang jelas
                    function renderRow($item) {
                        $item_id = $item['id'];
                        $item_type = $item['type'];
                        $item_title = $item['title'] ?? (strtoupper($item_type) . ' #' . $item_id);
                        $ver_status = $item['verification_status'] ?? 'Active/Pending';

                        $ver_badge = 'bg-warning bg-opacity-10 text-warning border border-warning border-opacity-25';
                        if ($ver_status === 'Verified') $ver_badge = 'bg-success bg-opacity-10 text-success border border-success border-opacity-25';
                        elseif ($ver_status === 'Rejected') $ver_badge = 'bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25';

                        $type_badge = $item_type === 'report' ? 'bg-info bg-opacity-10 text-info border border-info border-opacity-25' : 'bg-success bg-opacity-10 text-success border border-success border-opacity-25';

                        echo "<tr>";
                        echo "<td class='text-secondary font-monospace'>#{$item_id}</td>";
                        echo "<td class='fw-semibold text-white'>" . htmlspecialchars($item_title) . " <span class='badge {$type_badge} ms-2 px-2 py-1 fw-bold'>" . strtoupper($item_type) . "</span></td>";
                        echo "<td><span class='badge {$ver_badge} px-2.5 py-1.5 rounded-pill fw-semibold'><i class='bi bi-dot'></i> " . htmlspecialchars($ver_status) . "</span></td>";
                        echo "<td class='text-end'>";
                        echo "<div class='d-inline-flex gap-2 align-items-center justify-content-end'>";

                        // Dropdown Ubah Status Verifikasi
                        echo '<div class="btn-group">';
                        echo '<button class="btn btn-sm btn-outline-light dropdown-toggle py-1 px-3 border-opacity-25" type="button" data-bs-toggle="dropdown" aria-expanded="false">';
                        echo '<i class="bi bi-sliders me-1"></i> Verifikasi';
                        echo '</button>';
                        echo '<ul class="dropdown-menu dropdown-menu-dark bg-dark border border-secondary shadow-lg py-2" style="z-index: 9999 !important;">';
                        echo '<li><h6 class="dropdown-header text-secondary small text-uppercase">Ubah Status</h6></li>';
                        echo '<li><hr class="dropdown-divider border-secondary opacity-25"></li>';
                        echo '<li><a class="dropdown-item text-success small py-1.5" href="owner_dashboard.php?action=update_verification&id=' . $item_id . '&type=' . $item_type . '&status=Verified"><i class="bi bi-check-circle-fill me-1"></i> Verified</a></li>';
                        echo '<li><a class="dropdown-item text-warning small py-1.5" href="owner_dashboard.php?action=update_verification&id=' . $item_id . '&type=' . $item_type . '&status=Pending"><i class="bi bi-clock-fill me-1"></i> Pending</a></li>';
                        echo '<li><a class="dropdown-item text-danger small py-1.5" href="owner_dashboard.php?action=update_verification&id=' . $item_id . '&type=' . $item_type . '&status=Rejected"><i class="bi bi-x-circle-fill me-1"></i> Rejected</a></li>';
                        echo '</ul>';
                        echo '</div>';

                        // Tombol Hapus Item
                        echo "<a href='owner_dashboard.php?action=delete_item&id={$item_id}&type={$item_type}' class='btn btn-sm btn-outline-danger py-1 px-3' onclick=\"return confirm('Yakin ingin menghapus item ini?');\"><i class='bi bi-trash-fill me-1'></i> Hapus</a>";

                        echo "</div>";
                        echo "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/lenis@1.1.18/dist/lenis.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>