<?php
// Aktifkan session jika belum berjalan
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Sembunyikan error mentah untuk tampilan bersih
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Sertakan file konfigurasi asli proyek Anda
if (file_exists('config.php')) {
    require_once 'config.php';
}

// Cek sesi login secara fleksibel
$user_id = $_SESSION['user_id'] ?? ($_SESSION['id'] ?? null);
if (!$user_id) {
    header("Location: login.php");
    exit;
}

$vdp_id = isset($_GET['vdp_id']) ? intval($_GET['vdp_id']) : 0;
$program_title = "Program VDP #" . $vdp_id;
$success = false;
$error = "";

// Ambil judul program dari database menggunakan koneksi dari config.php
if (isset($conn) && $vdp_id > 0) {
    $res = @$conn->query("SELECT title FROM programs WHERE id = $vdp_id LIMIT 1");
    if ($res && $row = $res->fetch_assoc()) {
        $program_title = $row['title'] ?? $program_title;
    }
}

// Proses pengiriman laporan saat tombol diklik
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_vulnerability'])) {
    $title     = trim($_POST['title'] ?? '');
    $desc      = trim($_POST['description'] ?? '');
    $vuln_type = trim($_POST['vuln_type'] ?? 'Lainnya / Umum');
    $severity  = trim($_POST['severity'] ?? 'Medium');
    $allowed_severity = ['Low', 'Medium', 'High', 'Critical'];
    if (!in_array($severity, $allowed_severity)) {
        $severity = 'Medium';
    }

    if (!empty($title) && !empty($desc)) {
        if (isset($conn)) {
            // Simpan laporan ke tabel reports, lengkap dengan program_id
            // (sebelumnya tidak disimpan sama sekali, sehingga laporan tidak
            // bisa ditautkan kembali ke program & tidak bisa dibuka di
            // view_report.php) dan jenis kerentanan yang dipilih hacker.
            $stmt = $conn->prepare(
                "INSERT INTO reports (hacker_id, program_id, title, vulnerability_type, severity, vulnerability_details, status, payment_status, reward)
                 VALUES (?, ?, ?, ?, ?, ?, 'New', 'Unpaid', 0.00)"
            );
            if ($stmt) {
                $prog_id_param = $vdp_id > 0 ? $vdp_id : null;
                $stmt->bind_param("iissss", $user_id, $prog_id_param, $title, $vuln_type, $severity, $desc);
                if ($stmt->execute()) {
                    $success = true;
                } else {
                    $error = "Gagal menyimpan laporan ke database.";
                }
                $stmt->close();
            } else {
                $error = "Gagal menyiapkan query penyimpanan laporan.";
            }
        } else {
            $error = "Koneksi database tidak tersedia.";
        }
    } else {
        $error = "Judul dan deskripsi laporan wajib diisi.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kirim Laporan Kerentanan - HackerCrowd</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="assets/img/logo.svg">
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>

<nav class="navbar navbar-dark bg-dark px-4 py-3 sticky-top border-bottom border-secondary">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="dashboard.php">Hacker<span class="text-success">Crowd</span> Submit Portal</a>
        <a href="dashboard.php" class="btn btn-sm btn-outline-light rounded-pill px-3">Kembali ke Dashboard</a>
    </div>
</nav>

<div class="container my-5" style="max-width: 800px;">
    <div class="card card-stat p-4">
        <h4 class="fw-bold text-white mb-1"><i class="bi bi-bug-fill text-success me-2"></i>Kirim Laporan Celah Kerentanan</h4>
        <p class="text-secondary small mb-4">Target Program: <strong class="text-info"><?= htmlspecialchars($program_title, ENT_QUOTES, 'UTF-8'); ?></strong></p>

        <?php if ($success): ?>
            <div class="alert alert-success bg-success bg-opacity-10 border border-success text-success rounded-3 p-3 mb-4">
                <i class="bi bi-check-circle-fill me-2"></i> Laporan kerentanan Anda berhasil dikirim ke tim Owner/Company!
                <div class="mt-2"><a href="dashboard.php" class="btn btn-sm btn-success">Kembali ke Dashboard</a></div>
            </div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger bg-danger bg-opacity-10 border border-danger text-danger rounded-3 p-3 mb-4">
                <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label text-secondary small text-uppercase fw-bold">Judul Laporan Celah</label>
                <input type="text" name="title" class="form-control bg-dark text-white border-secondary" placeholder="Misal: SQL Injection pada parameter pencarian" required autocomplete="off">
            </div>

            <div class="mb-3">
                <label class="form-label text-secondary small text-uppercase fw-bold">Jenis Kerentanan</label>
                <select name="vuln_type" class="form-select bg-dark text-white border-secondary">
                    <option value="SQL Injection">SQL Injection</option>
                    <option value="Cross-Site Scripting (XSS)">Cross-Site Scripting (XSS)</option>
                    <option value="IDOR">IDOR / Broken Access Control</option>
                    <option value="Remote Code Execution (RCE)">Remote Code Execution (RCE)</option>
                    <option value="Lainnya">Lainnya / Umum</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label text-secondary small text-uppercase fw-bold">Tingkat Keparahan (Severity)</label>
                <select name="severity" class="form-select bg-dark text-white border-secondary">
                    <option value="Low">Low</option>
                    <option value="Medium" selected>Medium</option>
                    <option value="High">High</option>
                    <option value="Critical">Critical</option>
                </select>
            </div>

            <div class="mb-4">
                <label class="form-label text-secondary small text-uppercase fw-bold">Detail / Langkah Reproduksi (PoC)</label>
                <textarea name="description" rows="6" class="form-control bg-dark text-white border-secondary" placeholder="Jelaskan langkah-langkah untuk mereproduksi bug..." required></textarea>
            </div>

            <button type="submit" name="submit_vulnerability" class="btn btn-h1-green w-100 py-2.5"><i class="bi bi-send-fill me-2"></i> Kirim Laporan Sekarang</button>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/lenis@1.1.18/dist/lenis.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>