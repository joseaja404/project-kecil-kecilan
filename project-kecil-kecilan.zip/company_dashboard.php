<?php
// Aktifkan pelaporan error untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Panggil konfigurasi atau mulai session
if (file_exists('config.php')) {
    require_once 'config.php';
} else {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

// Proteksi: Hanya role 'company' yang boleh mengakses
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'company') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$success_msg = "";
$error_msg = "";

// Handle Aksi Update Status Laporan (Multi-Status)
if (isset($_GET['action']) && $_GET['action'] === 'update_status' && isset($_GET['id']) && isset($_GET['status']) && isset($conn)) {
    $report_id = intval($_GET['id']);
    $allowed_statuses = ['New', 'Triaged', 'In Progress', 'Resolved', 'Duplicate', 'Closed'];
    $new_status = trim($_GET['status']);

    if (in_array($new_status, $allowed_statuses)) {
        $chk_col = @$conn->query("SHOW COLUMNS FROM reports LIKE 'status'");
        if ($chk_col && $chk_col->num_rows > 0) {
            $stmt_up = $conn->prepare("UPDATE reports SET status = ? WHERE id = ?");
            if ($stmt_up) {
                $stmt_up->bind_param("si", $new_status, $report_id);
                if ($stmt_up->execute()) {
                    $success_msg = "Status laporan #{$report_id} berhasil diperbarui menjadi [{$new_status}]!";
                } else {
                    $error_msg = "Gagal memperbarui status laporan di database.";
                }
            }
        } else {
            $error_msg = "Kolom status belum tersedia pada tabel reports.";
        }
    } else {
        $error_msg = "Status laporan tidak valid.";
    }
}

// Handle Aksi Update Nominal Reward / Bounty Laporan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_reward') {
    $report_id = intval($_POST['report_id'] ?? 0);
    $reward_amount = trim($_POST['reward_amount'] ?? '$0.00');

    if ($report_id > 0 && isset($conn)) {
        $stmt_rw = $conn->prepare("UPDATE reports SET reward = ? WHERE id = ?");
        if ($stmt_rw) {
            $stmt_rw->bind_param("si", $reward_amount, $report_id);
            if ($stmt_rw->execute()) {
                $success_msg = "Nominal reward untuk laporan #{$report_id} berhasil diatur ke {$reward_amount}!";
            } else {
                $error_msg = "Gagal menyimpan nominal reward ke database.";
            }
        }
    }
}

// Handle Aksi Update Status VDP Program (Live / Paused / Closed)
if (isset($_GET['action']) && $_GET['action'] === 'update_vdp_status' && isset($_GET['id']) && isset($_GET['status']) && isset($conn)) {
    $vdp_id = intval($_GET['id']);
    $allowed_vdp_statuses = ['Live', 'Paused', 'Closed'];
    $new_vdp_status = trim($_GET['status']);

    if (in_array($new_vdp_status, $allowed_vdp_statuses)) {
        $stmt_up_vdp = $conn->prepare("UPDATE programs SET status = ? WHERE id = ? AND company_id = ?");
        if ($stmt_up_vdp) {
            $stmt_up_vdp->bind_param("sii", $new_vdp_status, $vdp_id, $user_id);
            if ($stmt_up_vdp->execute()) {
                $success_msg = "Status program VDP #{$vdp_id} berhasil diperbarui menjadi [{$new_vdp_status}]!";
            } else {
                $error_msg = "Gagal memperbarui status program VDP di database.";
            }
        }
    } else {
        $error_msg = "Status VDP tidak valid.";
    }
}

// Handle Form Publikasi / Upload Program VDP Baru secara defensif
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'publish_vdp') {
    $program_title = trim($_POST['program_title'] ?? '');
    $scope = trim($_POST['scope'] ?? '');
    $reward = trim($_POST['reward'] ?? '');

    if (!empty($program_title)) {
        if (isset($conn)) {
            $stmt_vdp = $conn->prepare("INSERT INTO programs (company_id, title, scope, reward, status) VALUES (?, ?, ?, ?, 'Live')");
            if ($stmt_vdp) {
                $stmt_vdp->bind_param("isss", $user_id, $program_title, $scope, $reward);
                if ($stmt_vdp->execute()) {
                    $success_msg = "Program VDP berhasil dipublikasikan!";
                } else {
                    $error_msg = "Gagal menyimpan program VDP ke database.";
                }
            } else {
                $error_msg = "Kesalahan database saat menyimpan VDP.";
            }
        }
    } else {
        $error_msg = "Judul program VDP tidak boleh kosong!";
    }
}

// Hitung Statistik Laporan & VDP
$total_vdp = 0;
$total_reports = 0;
$pending_reports = 0;
$resolved_reports = 0;

if (isset($conn)) {
    $res_vdp = @$conn->query("SELECT COUNT(*) as cnt FROM programs WHERE company_id = $user_id");
    if ($res_vdp) { $d = $res_vdp->fetch_assoc(); $total_vdp = $d['cnt'] ?? 0; }

    $chk_table = @$conn->query("SHOW TABLES LIKE 'reports'");
    if ($chk_table && $chk_table->num_rows > 0) {
        $res_tot = @$conn->query("SELECT COUNT(*) as cnt FROM reports");
        if ($res_tot) { $d = $res_tot->fetch_assoc(); $total_reports = $d['cnt'] ?? 0; }

        $res_pen = @$conn->query("SELECT COUNT(*) as cnt FROM reports WHERE status IN ('New', 'Triaged', 'In Progress') OR status IS NULL");
        if ($res_pen) { $d = $res_pen->fetch_assoc(); $pending_reports = $d['cnt'] ?? 0; }

        $res_res = @$conn->query("SELECT COUNT(*) as cnt FROM reports WHERE status = 'Resolved'");
        if ($res_res) { $d = $res_res->fetch_assoc(); $resolved_reports = $d['cnt'] ?? 0; }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Portal - HackerCrowd</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/svg+xml" href="assets/img/logo.svg">
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>

<div class="aurora-orb-dash orb-dash-1"></div>
<div class="aurora-orb-dash orb-dash-2"></div>

<!-- Top Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom px-4 py-3 sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold d-flex align-items-center" href="company_dashboard.php">
            <i class="bi bi-shield-shaded text-success fs-3 me-2"></i>
            <span class="fs-4">Hacker<span class="text-success">Crowd</span></span>
            <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 ms-3 px-3 py-1 fs-6 rounded-pill fw-semibold"><i class="bi bi-building me-1"></i> Company Portal</span>
        </a>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <a href="leaderboard.php" class="btn btn-sm btn-outline-success fw-bold px-3 rounded-pill border-opacity-50 py-2"><i class="bi bi-trophy me-1"></i> Leaderboard</a>
            <a href="messages.php" class="btn btn-sm btn-outline-success fw-bold px-3 rounded-pill border-opacity-50 py-2"><i class="bi bi-chat-dots me-1"></i> Live Chat</a>
            <a href="ai_mitigation.php" class="btn btn-sm btn-outline-success fw-bold d-flex align-items-center px-3 rounded-pill border-opacity-50 py-2">
                <i class="bi bi-cpu me-2"></i> AI Mitigation by HackerCrowd
            </a>
            <a href="logout.php" class="btn btn-sm btn-outline-danger fw-bold px-3 rounded-pill border-opacity-50 py-2"><i class="bi bi-box-arrow-right me-1"></i> Keluar</a>
        </div>
    </div>
</nav>

<!-- Main Container -->
<div class="container my-5" style="max-width: 1200px;">
    
    <?php if (!empty($success_msg)): ?>
        <div class="alert alert-success bg-success bg-opacity-15 border border-success text-success mb-4 rounded-3 py-3 px-4">
            <i class="bi bi-check-circle-fill me-2"></i> <?= htmlspecialchars($success_msg); ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($error_msg)): ?>
        <div class="alert alert-danger bg-danger bg-opacity-15 border border-danger text-danger mb-4 rounded-3 py-3 px-4">
            <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($error_msg); ?>
        </div>
    <?php endif; ?>

    <!-- Welcome Header Banner -->
    <div class="card-stat p-4 mb-4 border-success border-opacity-25">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <div class="d-flex align-items-center gap-2 mb-2">
                    <span class="status-dot"></span>
                    <span class="text-success small fw-semibold text-uppercase tracking-wider">VDP & Security Monitoring Active</span>
                </div>
                <h2 class="fw-bold text-white mb-2">Dashboard Perusahaan</h2>
                <p class="text-secondary small mb-0">Publikasikan program VDP, atur nominal reward/bounty untuk keperluan pajak hacker, dan kelola status laporan bug secara real-time.</p>
            </div>
            <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">
                <a href="ai_mitigation.php" class="btn btn-h1-green px-4 py-2.5">
                    <i class="bi bi-magic me-2"></i>Buat Patch AI untuk Bug
                </a>
            </div>
        </div>
    </div>

    <!-- Analytics Cards -->
    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="card card-stat p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-secondary small text-uppercase fw-bold">Program VDP Anda</span>
                    <div class="stat-icon-wrapper text-success"><i class="bi bi-shield-check"></i></div>
                </div>
                <h1 class="fw-bold text-white display-5 mb-1"><?= $total_vdp ?></h1>
                <div class="text-success small fw-semibold"><i class="bi bi-globe me-1"></i> Program terdaftar</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-stat p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-secondary small text-uppercase fw-bold">Laporan Aktif (Pending)</span>
                    <div class="stat-icon-wrapper text-warning"><i class="bi bi-exclamation-triangle-fill"></i></div>
                </div>
                <h1 class="fw-bold text-white display-5 mb-1"><?= $pending_reports ?></h1>
                <div class="text-warning small fw-semibold"><i class="bi bi-clock-history me-1"></i> Perlu tindakan mitigasi</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-stat p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-secondary small text-uppercase fw-bold">Selesai Ditambal</span>
                    <div class="stat-icon-wrapper text-info"><i class="bi bi-shield-fill-check"></i></div>
                </div>
                <h1 class="fw-bold text-white display-5 mb-1"><?= $resolved_reports ?></h1>
                <div class="text-info small fw-semibold"><i class="bi bi-check-circle-fill me-1"></i> Telah diamankan</div>
            </div>
        </div>
    </div>

    <!-- Form Publikasi / Upload Program VDP Baru -->
    <div class="card card-stat p-4 mb-5 border-success border-opacity-25">
        <div class="d-flex align-items-center mb-3">
            <i class="bi bi-cloud-arrow-up-fill text-success fs-4 me-2"></i>
            <h5 class="fw-bold text-white mb-0">Publikasikan / Unggah Program VDP Baru</h5>
        </div>
        <p class="text-secondary small mb-4">Buat target program keamanan baru agar dapat diakses dan diuji oleh para peneliti keamanan terverifikasi.</p>
        
        <form method="POST" action="">
            <input type="hidden" name="action" value="publish_vdp">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label text-secondary small fw-semibold">Nama Program / Target VDP</label>
                    <input type="text" name="program_title" class="form-control bg-dark text-white border-secondary" placeholder="Contoh: Bug Bounty Portal API v2" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label text-secondary small fw-semibold">Bounty / Estimasi Penghargaan</label>
                    <input type="text" name="reward" class="form-control bg-dark text-white border-secondary" placeholder="Contoh: $100 - $1,000 / Swag">
                </div>
                <div class="col-12">
                    <label class="form-label text-secondary small fw-semibold">Ruang Lingkup (Scope) & Aturan Pengujian</label>
                    <textarea name="scope" class="form-control bg-dark text-white border-secondary" rows="3" placeholder="Contoh: Domain utama (*.example.com) diperbolehkan." required></textarea>
                </div>
                <div class="col-12 text-end">
                    <button type="submit" class="btn btn-h1-green px-4 py-2.5">
                        <i class="bi bi-send-fill me-2"></i>Publikasikan Program VDP
                    </button>
                </div>
            </div>
        </form>
    </div>

    <!-- Daftar Program VDP Saya -->
    <div class="card card-stat p-4 mb-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h5 class="fw-bold text-white mb-1"><i class="bi bi-shield-check text-success me-2"></i>Program VDP Anda (Aktif / Nonaktif)</h5>
                <p class="text-secondary small mb-0">Kelola status program VDP Anda (Live, Paused, atau Closed).</p>
            </div>
            <span class="badge bg-dark border border-secondary text-secondary px-3 py-2 rounded-pill">My VDP Programs</span>
        </div>
        <div class="table-responsive">
            <table class="table table-dark-custom align-middle mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Judul Program</th>
                        <th>Ruang Lingkup (Scope)</th>
                        <th>Reward</th>
                        <th>Status VDP</th>
                        <th class="text-end">Ubah Status VDP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (isset($conn)) {
                        $q_my_vdp = @$conn->query("SELECT * FROM programs WHERE company_id = $user_id ORDER BY id DESC");
                        if (true) {
                            if ($q_my_vdp && $q_my_vdp->num_rows > 0) {
                                while ($v = $q_my_vdp->fetch_assoc()) {
                                    $vdp_status = $v['status'] ?? 'Live';
                                    
                                    $vdp_badge = 'bg-success bg-opacity-10 text-success border border-success border-opacity-25';
                                    if ($vdp_status === 'Paused') $vdp_badge = 'bg-warning bg-opacity-10 text-warning border border-warning border-opacity-25';
                                    elseif ($vdp_status === 'Closed') $vdp_badge = 'bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25';

                                    echo "<tr>";
                                    echo "<td class='text-secondary font-monospace'>#{$v['id']}</td>";
                                    echo "<td class='fw-semibold text-white'>" . htmlspecialchars($v['title']) . "</td>";
                                    echo "<td class='text-secondary text-truncate' style='max-width: 250px;'>" . htmlspecialchars($v['scope']) . "</td>";
                                    echo "<td class='text-success fw-semibold'>" . htmlspecialchars($v['reward']) . "</td>";
                                    echo "<td><span class='badge {$vdp_badge} px-2.5 py-1.5 rounded-pill fw-semibold'><i class='bi bi-dot'></i> " . htmlspecialchars($vdp_status) . "</span></td>";
                                    echo "<td class='text-end'>";
                                    
                                    echo '<div class="btn-group dropup">';
                                    echo '<button class="btn btn-sm btn-outline-light dropdown-toggle py-1.5 px-3 border-opacity-25" type="button" data-bs-toggle="dropdown" aria-expanded="false">';
                                    echo '<i class="bi bi-toggle-on me-1"></i> Status VDP';
                                    echo '</button>';
                                    echo '<ul class="dropdown-menu dropdown-menu-dark bg-dark border border-secondary shadow-lg py-2" style="z-index: 9999 !important;">';
                                    echo '<li><h6 class="dropdown-header text-secondary small text-uppercase">Atur Program VDP</h6></li>';
                                    echo '<li><hr class="dropdown-divider border-secondary opacity-25"></li>';
                                    echo '<li><a class="dropdown-item text-success small py-1.5" href="company_dashboard.php?action=update_vdp_status&id=' . $v['id'] . '&status=Live"><i class="bi bi-play-fill me-1"></i> Live (Aktif)</a></li>';
                                    echo '<li><a class="dropdown-item text-warning small py-1.5" href="company_dashboard.php?action=update_vdp_status&id=' . $v['id'] . '&status=Paused"><i class="bi bi-pause-fill me-1"></i> Paused (Nonaktif)</a></li>';
                                    echo '<li><a class="dropdown-item text-danger small py-1.5" href="company_dashboard.php?action=update_vdp_status&id=' . $v['id'] . '&status=Closed"><i class="bi bi-stop-fill me-1"></i> Closed (Tutup)</a></li>';
                                    echo '</ul>';
                                    echo '</div>';

                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='6' class='text-center text-muted py-4'>Anda belum mengunggah program VDP apa pun.</td></tr>";
                            }
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Incoming Submissions Table (Laporan Kerentanan Masuk + Reward Payout Management) -->
    <div class="card card-stat p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h5 class="fw-bold text-white mb-1"><i class="bi bi-file-earmark-text-fill text-success me-2"></i>Laporan Kerentanan Masuk (Vulnerability Reports)</h5>
                <p class="text-secondary small mb-0">Tinjau laporan, atur nominal reward/payout untuk pajak hacker, dan perbarui status.</p>
            </div>
            <span class="badge bg-dark border border-secondary text-secondary px-3 py-2 rounded-pill">Incoming Submissions</span>
        </div>
        <div class="table-responsive">
            <table class="table table-dark-custom align-middle mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Judul Kerentanan</th>
                        <th>Pelapor (Hacker)</th>
                        <th>Status</th>
                        <th>Reward / Payout ($)</th>
                        <th class="text-end">Aksi & Ubah Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (isset($conn)) {
                        $chk_tbl = @$conn->query("SHOW TABLES LIKE 'reports'");
                        if ($chk_tbl && $chk_tbl->num_rows > 0) {
                            $q_reps = @$conn->query("SELECT * FROM reports ORDER BY id DESC LIMIT 15");
                            if ($q_reps && $q_reps->num_rows > 0) {
                                while ($r = $q_reps->fetch_assoc()) {
                                    $title = $r['report_title'] ?? ($r['title'] ?? 'Laporan #' . $r['id']);
                                    $hacker_name = $r['hacker_name'] ?? ($r['username'] ?? 'Anonymous Hacker');
                                    $status = $r['status'] ?? 'New';
                                    $current_reward = $r['reward'] ?? ($r['bounty'] ?? '$350.00');
                                    
                                    $badge_class = 'bg-secondary bg-opacity-10 text-secondary border border-secondary border-opacity-25';
                                    if ($status === 'Resolved') $badge_class = 'bg-success bg-opacity-10 text-success border border-success border-opacity-25';
                                    elseif ($status === 'Triaged') $badge_class = 'bg-info bg-opacity-10 text-info border border-info border-opacity-25';
                                    elseif ($status === 'In Progress') $badge_class = 'bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25';
                                    elseif ($status === 'Duplicate') $badge_class = 'bg-warning bg-opacity-10 text-warning border border-warning border-opacity-25';
                                    elseif ($status === 'Closed') $badge_class = 'bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25';
                                    elseif ($status === 'New') $badge_class = 'bg-warning bg-opacity-10 text-warning border border-warning border-opacity-25';

                                    echo "<tr>";
                                    echo "<td class='text-secondary font-monospace'>#{$r['id']}</td>";
                                    echo "<td class='fw-semibold text-white'>" . htmlspecialchars($title) . "</td>";
                                    echo "<td class='text-secondary'>" . htmlspecialchars($hacker_name) . "</td>";
                                    echo "<td><span class='badge {$badge_class} px-2.5 py-1.5 rounded-pill fw-semibold'>" . htmlspecialchars($status) . "</span></td>";
                                    
                                    // Kolom Input Reward / Payout Langsung untuk Pajak Hacker
                                    echo "<td>";
                                    echo '<form method="POST" action="" class="d-flex align-items-center gap-1 m-0">';
                                    echo '<input type="hidden" name="action" value="update_reward">';
                                    echo '<input type="hidden" name="report_id" value="' . $r['id'] . '">';
                                    echo '<input type="text" name="reward_amount" value="' . htmlspecialchars($current_reward) . '" class="form-control form-control-sm bg-dark text-success border-secondary font-monospace fw-bold" style="width: 90px;" placeholder="$0.00" required>';
                                    echo '<button type="submit" class="btn btn-sm btn-outline-success px-2 py-1" title="Simpan Reward"><i class="bi bi-check-lg"></i></button>';
                                    echo '</form>';
                                    echo "</td>";

                                    echo "<td class='text-end'>";
                                    echo "<div class='d-inline-flex gap-2 align-items-center justify-content-end'>";
                                    
                                    // Tombol Buat Patch AI
                                    echo "<a href='ai_mitigation.php?report_id={$r['id']}' class='btn btn-sm btn-h1-green py-1.5 px-3'><i class='bi bi-cpu me-1'></i> Patch AI</a>";
                                    
                                    // Dropdown Menu Pilihan Status Laporan
                                    echo '<div class="btn-group dropup">';
                                    echo '<button class="btn btn-sm btn-outline-light dropdown-toggle py-1.5 px-3 border-opacity-25" type="button" data-bs-toggle="dropdown" aria-expanded="false">';
                                    echo '<i class="bi bi-sliders me-1"></i> Status';
                                    echo '</button>';
                                    echo '<ul class="dropdown-menu dropdown-menu-dark bg-dark border border-secondary shadow-lg py-2" style="z-index: 9999 !important;">';
                                    echo '<li><h6 class="dropdown-header text-secondary small text-uppercase">Ubah Status Laporan</h6></li>';
                                    echo '<li><hr class="dropdown-divider border-secondary opacity-25"></li>';
                                    echo '<li><a class="dropdown-item text-warning small py-1.5" href="company_dashboard.php?action=update_status&id=' . $r['id'] . '&status=New"><i class="bi bi-dot me-1"></i> New</a></li>';
                                    echo '<li><a class="dropdown-item text-info small py-1.5" href="company_dashboard.php?action=update_status&id=' . $r['id'] . '&status=Triaged"><i class="bi bi-dot me-1"></i> Triaged</a></li>';
                                    echo '<li><a class="dropdown-item text-primary small py-1.5" href="company_dashboard.php?action=update_status&id=' . $r['id'] . '&status=In Progress"><i class="bi bi-dot me-1"></i> In Progress</a></li>';
                                    echo '<li><a class="dropdown-item text-success small py-1.5" href="company_dashboard.php?action=update_status&id=' . $r['id'] . '&status=Resolved"><i class="bi bi-dot me-1"></i> Resolved</a></li>';
                                    echo '<li><a class="dropdown-item text-secondary small py-1.5" href="company_dashboard.php?action=update_status&id=' . $r['id'] . '&status=Duplicate"><i class="bi bi-dot me-1"></i> Duplicate</a></li>';
                                    echo '<li><a class="dropdown-item text-danger small py-1.5" href="company_dashboard.php?action=update_status&id=' . $r['id'] . '&status=Closed"><i class="bi bi-dot me-1"></i> Closed</a></li>';
                                    echo '</ul>';
                                    echo '</div>';

                                    echo "</div>";
                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='6' class='text-center text-muted py-5'>Belum ada laporan kerentanan yang masuk dari peneliti keamanan.</td></tr>";
                            }
                        } else {
                            echo "<tr><td colspan='6' class='text-center text-muted py-5'>Tabel laporan belum tersedia di database.</td></tr>";
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/lenis@1.1.18/dist/lenis.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>